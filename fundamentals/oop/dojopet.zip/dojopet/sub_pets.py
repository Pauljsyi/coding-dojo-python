
class Troy():
  def __init__(self, name, type, tricks):
    super().__init__(name, type, tricks)
    
  pass

class Cody():
  def __init__(self, name, type, tricks):
    super().__init__(name, type, tricks)
    
  pass

class Penny():
  def __init__(self, name, type, tricks):
    super().__init__(name, type, tricks)
    
  pass