class Ninja:
  def __init__( self, first_name , last_name , treats , pet_food , pet ):
    self.first_name = first_name
    self.last_name = last_name
    self.treats = treats
    self.pet_food = pet_food
    self.pet = pet
    
    
    
# implement the following methods:
# walk() - walks the ninja's pet invoking the pet play() method
  def walk(self):
    self.pet.play()
    return self
# feed() - feeds the ninja's pet invoking the pet eat() method
  def feed(self):
    self.pet.eat()
    return self
# bathe() - cleans the ninja's pet invoking the pet noise() method
  def bathe(self, sound):
    self.pet.noise(sound)
    return self


class Pet:
  def __init__(self, name , type , tricks):
    self.name = name
    self.type = type
    self.tricks = tricks
    self.energy = 100
    self.health = 100


  # implement the following methods:
  # sleep() - increases the pets energy by 25
  def sleep(self):
    self.energy += 25
    print(f'energy level rose by 25 points ... current energy level {self.energy}')
  # eat() - increases the pet's energy by 5 & health by 10
  def eat(self):
    self.energy += 5
    self.health += 10
    print(f'energy level rose by 5 points and health rose by 10 points  ... current energy level {self.energy}  ... current health level {self.health}')
  # play(self) - increases the pet's health by 5
  def play(self):
    self.health -= 5
    print(f'health -5 points  ... current health level {self.health}')
  # noise() - prints out the pet's sound
  def noise(self, sound):
    print(f"Your pet {self.name} let out a {sound}")


# class Ninja:
  # def __init__( self, first_name , last_name , treats , pet_food , pet )
# class Pet:
  # def __init__( self, name , type , tricks )
paul = Ninja('paul', 'yi', 'turkey', 'kibble', Pet('troy', 'german shepherd', ['sit', 'down', 'stay']))

paul.walk().feed().bathe('meow')